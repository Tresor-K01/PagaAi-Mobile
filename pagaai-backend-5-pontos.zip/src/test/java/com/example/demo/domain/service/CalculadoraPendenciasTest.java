package com.example.demo.domain.service;

import com.example.demo.domain.dto.Response.MesPendenteResponse;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

// Testes da regra de pendencias. Nao precisam do banco: rode com  ./mvnw test -Dtest=CalculadoraPendenciasTest
class CalculadoraPendenciasTest {

    private static final BigDecimal VINTE = new BigDecimal("20.00");

    @Test
    void mesesSemPagamentoFicamPendentes() {
        // Entrou em julho, pagou so julho; hoje e 15/09 (vencimento dia 10)
        Map<YearMonth, BigDecimal> pagos = Map.of(YearMonth.of(2026, 7), VINTE);

        List<MesPendenteResponse> meses = CalculadoraPendencias.calcular(VINTE, 10,
                LocalDate.of(2026, 7, 1), null, pagos, LocalDate.of(2026, 9, 15));

        assertEquals(2, meses.size()); // agosto e setembro
        assertEquals("2026-08", meses.get(0).mes());
        assertEquals(new BigDecimal("40.00"), CalculadoraPendencias.total(meses));
    }

    @Test
    void mesAindaNaoVencidoNaoContaComoPendente() {
        List<MesPendenteResponse> meses = CalculadoraPendencias.calcular(VINTE, 10,
                LocalDate.of(2026, 9, 1), null, Map.of(), LocalDate.of(2026, 9, 10));

        assertTrue(meses.isEmpty()); // vence hoje, ainda nao esta atrasado
    }

    @Test
    void pagamentoParcialDeixaADiferencaPendente() {
        Map<YearMonth, BigDecimal> pagos = Map.of(YearMonth.of(2026, 9), new BigDecimal("15.00"));

        List<MesPendenteResponse> meses = CalculadoraPendencias.calcular(VINTE, 10,
                LocalDate.of(2026, 9, 1), null, pagos, LocalDate.of(2026, 9, 20));

        assertEquals(1, meses.size());
        assertEquals(new BigDecimal("5.00"), meses.get(0).valorPendente());
    }

    @Test
    void moradorQueSaiuNaoAcumulaMesesDepoisDaSaida() {
        List<MesPendenteResponse> meses = CalculadoraPendencias.calcular(VINTE, 10,
                LocalDate.of(2026, 6, 1), LocalDate.of(2026, 7, 31), Map.of(), LocalDate.of(2026, 10, 1));

        assertEquals(2, meses.size()); // junho e julho
    }

    @Test
    void moradorSemMensalidadeNaoTemPendencia() {
        assertTrue(CalculadoraPendencias.calcular(null, 10, LocalDate.of(2026, 1, 1), null,
                Map.of(), LocalDate.of(2026, 10, 1)).isEmpty());
    }
}
