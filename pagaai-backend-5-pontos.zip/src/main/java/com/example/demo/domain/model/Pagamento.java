package com.example.demo.domain.model;


import com.example.demo.domain.model.enums.StatusPagamento;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Data
@NoArgsConstructor
@Table(name="pagamento")
public class Pagamento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /** Usuario (administrador) que registrou o pagamento. */
    @ManyToOne
    @JoinColumn(name="id_usuario")
    private Usuario usuario;


    @ManyToOne
    @JoinColumn(name = "id_morador")
    private Morador morador;

    private BigDecimal valor;

    /** CONCLUIDO ao registrar; CANCELADO quando foi lancado por engano (nao e apagado). */
    @Enumerated(EnumType.STRING)
    private StatusPagamento statusPagamento;

    @Column(name = "data_pagamento")
    private LocalDate dateDoPagamento;    // LocalDate mapeia perfeitamente para o tipo DATE do banco

    /** Mensalidade a que o pagamento se refere, no formato "AAAA-MM" (ex.: "2026-09"). */
    @Column(name = "mes_referencia", length = 7)
    private String mesReferencia;

    /** Ex.: "Dinheiro", "Pix", "Transferencia". */
    @Column(name = "forma_pagamento", length = 30)
    private String formaPagamento;

    @Column(name = "observacao")
    private String observacao;
}
