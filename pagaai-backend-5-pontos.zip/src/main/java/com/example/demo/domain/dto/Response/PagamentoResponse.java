package com.example.demo.domain.dto.Response;

import com.example.demo.domain.model.enums.StatusPagamento;

import java.math.BigDecimal;
import java.time.LocalDate;

// Nao expoe as entidades Usuario/Morador inteiras, so o que o app precisa mostrar.
public record PagamentoResponse(
        Integer id,
        Integer moradorId,
        String nomeMorador,
        String numeroQuarto,
        BigDecimal valor,
        LocalDate dataPagamento,
        String mesReferencia,
        String formaPagamento,
        String observacao,
        StatusPagamento statusPagamento,
        String registradoPor
) {
}
