package com.example.demo.domain.service;

import com.example.demo.domain.dto.Request.PagamentoRequest;
import com.example.demo.domain.dto.Response.PagamentoResponse;
import com.example.demo.domain.model.Morador;
import com.example.demo.domain.model.Pagamento;
import com.example.demo.domain.model.Usuario;
import com.example.demo.domain.model.enums.StatusPagamento;
import com.example.demo.domain.repository.PagamentoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.List;

@Service
public class PagamentoService{

    @Autowired
    private PagamentoRepository pagamentoRepository;

    @Autowired
    private MoradorService moradorService;

    /** Registra o pagamento de uma mensalidade. "admin" e quem esta logado. */
    @Transactional
    public PagamentoResponse cadastrarPagamento(PagamentoRequest request, Usuario admin){
        Morador morador = moradorService.obter(request.moradorId());
        if (!morador.estaAtivo()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Nao e possivel registrar pagamento para morador inativo.");
        }
        if (request.dataPagamento().isAfter(LocalDate.now())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "A data do pagamento nao pode estar no futuro.");
        }

        Pagamento pagamento = new Pagamento();
        pagamento.setMorador(morador);
        pagamento.setUsuario(admin);
        pagamento.setValor(request.valor());
        pagamento.setDateDoPagamento(request.dataPagamento());
        pagamento.setMesReferencia(request.mesReferencia());
        pagamento.setFormaPagamento(request.formaPagamento());
        pagamento.setObservacao(request.observacao());
        pagamento.setStatusPagamento(StatusPagamento.CONCLUIDO);

        return toResponse(pagamentoRepository.save(pagamento));
    }

    /** Sem moradorId: todos os pagamentos. Com moradorId: so os daquele morador. */
    public List<PagamentoResponse> listarPagamentos(Integer moradorId){
        List<Pagamento> pagamentos = moradorId != null
                ? pagamentoRepository.listarPorMorador(moradorId)
                : pagamentoRepository.listarValidos();
        return pagamentos.stream().map(this::toResponse).toList();
    }

    public PagamentoResponse buscarPorId(Integer id){
        return toResponse(obter(id));
    }

    /** Pagamento lancado por engano: fica CANCELADO e deixa de contar nos totais e nas pendencias. */
    @Transactional
    public void cancelarPagamento(Integer id){
        Pagamento pagamento = obter(id);
        if (pagamento.getStatusPagamento() == StatusPagamento.CANCELADO) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Este pagamento ja esta cancelado.");
        }
        pagamento.setStatusPagamento(StatusPagamento.CANCELADO);
        pagamentoRepository.save(pagamento);
    }

    private Pagamento obter(Integer id){
        return pagamentoRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Pagamento " + id + " nao encontrado."));
    }

    private PagamentoResponse toResponse(Pagamento pagamento){
        Morador morador = pagamento.getMorador();
        Usuario moradorUsuario = morador != null ? morador.getUsuario() : null;
        return new PagamentoResponse(
                pagamento.getId(),
                morador != null ? morador.getId() : null,
                moradorUsuario != null ? moradorUsuario.getNome() : null,
                morador != null ? morador.getNumero_do_quarto() : null,
                pagamento.getValor(),
                pagamento.getDateDoPagamento(),
                pagamento.getMesReferencia(),
                pagamento.getFormaPagamento(),
                pagamento.getObservacao(),
                pagamento.getStatusPagamento(),
                pagamento.getUsuario() != null ? pagamento.getUsuario().getNome() : null
        );
    }
}
