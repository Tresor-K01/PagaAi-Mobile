package com.example.demo.domain.dto.Request;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Exemplo:
 * { "moradorId": 2, "valor": 20.00, "dataPagamento": "2026-09-05", "mesReferencia": "2026-09",
 *   "formaPagamento": "Pix" }
 */
public record PagamentoRequest(
        @NotNull(message = "Informe o morador") Integer moradorId,
        @NotNull(message = "Informe o valor") @Positive(message = "O valor deve ser maior que zero") BigDecimal valor,
        @NotNull(message = "Informe a data do pagamento") LocalDate dataPagamento,
        @NotNull(message = "Informe o mes de referencia")
        @Pattern(regexp = "\\d{4}-(0[1-9]|1[0-2])", message = "Mes de referencia no formato AAAA-MM, ex.: 2026-09")
        String mesReferencia,
        @Size(max = 30) String formaPagamento,
        String observacao
) {
}
