package com.example.demo.domain.dto.Response;

import com.example.demo.domain.model.enums.StatusUsuario;

// O app guarda o token e usa o perfil para abrir a tela do admin ou do morador
public record LoginResponse(
        String token,
        String tipo,
        long expiraEmSegundos,
        Integer usuarioId,
        String nome,
        StatusUsuario perfil
) {
}
