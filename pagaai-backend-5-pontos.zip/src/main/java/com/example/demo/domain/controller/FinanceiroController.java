package com.example.demo.domain.controller;

import com.example.demo.domain.dto.Response.DashboardAdminResponse;
import com.example.demo.domain.service.FinanceiroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

// Somente ADMIN (ver SecurityConfig)
@RestController
@CrossOrigin("*")
@RequestMapping("api/financeiro")
public class FinanceiroController {

    @Autowired
    private FinanceiroService financeiroService;

    /** GET /api/financeiro/dashboard  ou  ?inicio=2026-09-01&fim=2026-09-30 */
    @GetMapping("/dashboard")
    public ResponseEntity<DashboardAdminResponse> dashboard(@RequestParam(required = false) LocalDate inicio,
                                                            @RequestParam(required = false) LocalDate fim) {
        return new ResponseEntity<>(financeiroService.dashboard(inicio, fim), HttpStatus.OK);
    }
}
