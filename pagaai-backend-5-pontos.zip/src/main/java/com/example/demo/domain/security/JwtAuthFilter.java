package com.example.demo.domain.security;

import com.example.demo.domain.model.Morador;
import com.example.demo.domain.model.Usuario;
import com.example.demo.domain.model.enums.StatusUsuario;
import com.example.demo.domain.repository.MoradorRepository;
import com.example.demo.domain.repository.UsuarioRepository;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/**
 * Le o cabecalho "Authorization: Bearer <token>" de cada requisicao.
 * Se o token for valido, marca a requisicao como autenticada com o Usuario dono do token.
 *
 * Nao e @Component de proposito: e criado no SecurityConfig para nao rodar duas vezes.
 */
public class JwtAuthFilter extends OncePerRequestFilter {

    private final JwtService jwtService;
    private final UsuarioRepository usuarioRepository;
    private final MoradorRepository moradorRepository;

    public JwtAuthFilter(JwtService jwtService, UsuarioRepository usuarioRepository,
                         MoradorRepository moradorRepository) {
        this.jwtService = jwtService;
        this.usuarioRepository = usuarioRepository;
        this.moradorRepository = moradorRepository;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {

        String cabecalho = request.getHeader("Authorization");
        if (cabecalho != null && cabecalho.startsWith("Bearer ")) {
            Integer usuarioId = jwtService.validarEObterUsuarioId(cabecalho.substring(7));
            if (usuarioId != null) {
                usuarioRepository.findById(usuarioId)
                        .filter(this::podeAcessar)
                        .ifPresent(usuario -> SecurityContextHolder.getContext().setAuthentication(
                                new UsernamePasswordAuthenticationToken(usuario, null, usuario.getAuthorities())));
            }
        }
        chain.doFilter(request, response);
    }

    /** Morador inativo perde o acesso, mesmo que ainda tenha um token valido. */
    private boolean podeAcessar(Usuario usuario) {
        if (usuario.getStatusUsuario() != StatusUsuario.ROLE_MORADOR) {
            return true;
        }
        return moradorRepository.findById(usuario.getId()).map(Morador::estaAtivo).orElse(true);
    }
}
