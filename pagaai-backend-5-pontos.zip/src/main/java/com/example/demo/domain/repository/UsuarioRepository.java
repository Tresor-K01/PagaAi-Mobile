package com.example.demo.domain.repository;

import com.example.demo.domain.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {

    // Login: o usuario pode digitar o e-mail ou o telefone
    Optional<Usuario> findFirstByEmailOrTelefone(String email, String telefone);

    boolean existsByEmail(String email);

    boolean existsByTelefone(String telefone);
}
