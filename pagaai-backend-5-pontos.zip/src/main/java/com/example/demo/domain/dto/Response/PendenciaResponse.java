package com.example.demo.domain.dto.Response;

import java.math.BigDecimal;
import java.util.List;

// Situacao de pendencias de um morador
public record PendenciaResponse(
        Integer moradorId,
        String nome,
        String numeroQuarto,
        String telefone,
        int quantidadeMeses,
        BigDecimal valorTotal,
        List<MesPendenteResponse> meses
) {
}
