package com.example.demo.domain.dto.Response;

import java.math.BigDecimal;
import java.time.LocalDate;

// Dados do morador para o app. Nao expoe o objeto Usuario (nem a senha).
public record MoradorDetalheResponse(
        Integer id,
        String nome,
        String email,
        String telefone,
        String numeroQuarto,
        BigDecimal valorMensalidade,
        Integer diaVencimento,
        LocalDate dataEntrada,
        LocalDate dataSaida,
        boolean ativo
) {
}
