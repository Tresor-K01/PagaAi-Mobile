package com.example.demo.domain.dto.Response;

import java.math.BigDecimal;
import java.time.LocalDate;

// Linha do extrato: um pagamento (RECEITA) ou uma despesa (DESPESA)
public record MovimentacaoResponse(
        String tipo,
        Integer id,
        String descricao,
        BigDecimal valor,
        LocalDate data
) {
}
