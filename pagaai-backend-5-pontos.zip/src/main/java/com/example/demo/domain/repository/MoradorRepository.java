package com.example.demo.domain.repository;

import com.example.demo.domain.model.Morador;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MoradorRepository extends JpaRepository<Morador, Integer> {

    // "ativo is null" inclui os moradores cadastrados antes da coluna existir
    @Query("select m from Morador m where m.ativo is null or m.ativo = true order by m.usuario.nome")
    List<Morador> listarAtivos();

    @Query("select count(m) from Morador m where m.ativo is null or m.ativo = true")
    long contarAtivos();

    @Query("""
            select m from Morador m
            where (m.ativo is null or m.ativo = true)
              and (lower(m.usuario.nome) like lower(concat('%', :termo, '%'))
                   or lower(m.numero_do_quarto) like lower(concat('%', :termo, '%')))
            order by m.usuario.nome
            """)
    List<Morador> pesquisar(@Param("termo") String termo);
}
