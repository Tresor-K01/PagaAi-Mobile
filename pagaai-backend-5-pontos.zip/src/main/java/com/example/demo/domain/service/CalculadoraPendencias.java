package com.example.demo.domain.service;

import com.example.demo.domain.dto.Response.MesPendenteResponse;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Regra das pendencias, sem banco de dados (por isso e facil de testar):
 * - cobra uma mensalidade por mes, do mes de entrada ate o mes atual (ou o mes de saida);
 * - um mes so conta como atrasado depois do dia de vencimento;
 * - um mes esta pendente se o total pago para ele for menor que a mensalidade.
 *
 * Limitacao conhecida: usa a mensalidade atual do morador para todos os meses.
 */
public final class CalculadoraPendencias {

    private CalculadoraPendencias() {
    }

    public static List<MesPendenteResponse> calcular(BigDecimal mensalidade, Integer diaVencimento,
                                                     LocalDate dataEntrada, LocalDate dataSaida,
                                                     Map<YearMonth, BigDecimal> pagoPorMes, LocalDate hoje) {
        List<MesPendenteResponse> pendentes = new ArrayList<>();
        if (mensalidade == null || mensalidade.signum() <= 0 || dataEntrada == null) {
            return pendentes; // morador sem dados financeiros: nada a cobrar
        }
        int dia = diaVencimento != null ? diaVencimento : 10;

        YearMonth primeiro = YearMonth.from(dataEntrada);
        YearMonth ultimo = YearMonth.from(dataSaida != null && dataSaida.isBefore(hoje) ? dataSaida : hoje);

        for (YearMonth mes = primeiro; !mes.isAfter(ultimo); mes = mes.plusMonths(1)) {
            LocalDate vencimento = mes.atDay(Math.min(dia, mes.lengthOfMonth()));
            if (!hoje.isAfter(vencimento)) {
                continue; // ainda nao venceu
            }
            BigDecimal pago = pagoPorMes.getOrDefault(mes, BigDecimal.ZERO);
            BigDecimal falta = mensalidade.subtract(pago);
            if (falta.signum() > 0) {
                pendentes.add(new MesPendenteResponse(mes.toString(), vencimento, mensalidade, pago, falta));
            }
        }
        return pendentes;
    }

    public static BigDecimal total(List<MesPendenteResponse> meses) {
        return meses.stream().map(MesPendenteResponse::valorPendente).reduce(BigDecimal.ZERO, BigDecimal::add);
    }
}
