package com.example.demo.domain.dto.Response;

import com.example.demo.domain.model.enums.StatusUsuario;

// A senha NAO sai na resposta, nem mesmo o hash.
public record UsuarioResponse(
        Integer id,
        String  nome,
        String email,
        String Telefone,
        StatusUsuario statusUsuario
) {
}
