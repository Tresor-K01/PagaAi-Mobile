package com.example.demo.domain.controller;

import com.example.demo.domain.dto.Response.PendenciaResponse;
import com.example.demo.domain.model.Usuario;
import com.example.demo.domain.service.PendenciaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
@RequestMapping("api/pendencias")
public class PendenciaController {

    @Autowired
    private PendenciaService pendenciaService;

    /** ADMIN: moradores com mensalidades em atraso. */
    @GetMapping
    public ResponseEntity<List<PendenciaResponse>> listarPendencias() {
        return new ResponseEntity<>(pendenciaService.listarPendencias(), HttpStatus.OK);
    }

    /** MORADOR: as pendencias dele mesmo. O id vem do token, nunca da URL. */
    @GetMapping("/minhas")
    public ResponseEntity<PendenciaResponse> minhasPendencias(@AuthenticationPrincipal Usuario morador) {
        return new ResponseEntity<>(pendenciaService.pendenciasDoMorador(morador.getId()), HttpStatus.OK);
    }

    /** ADMIN: detalhe mes a mes de um morador. */
    @GetMapping("/{moradorId}")
    public ResponseEntity<PendenciaResponse> pendenciasDoMorador(@PathVariable Integer moradorId) {
        return new ResponseEntity<>(pendenciaService.pendenciasDoMorador(moradorId), HttpStatus.OK);
    }
}
