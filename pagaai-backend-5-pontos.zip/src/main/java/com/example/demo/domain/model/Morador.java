package com.example.demo.domain.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@NoArgsConstructor
@Data
@Table(name = "morador")
public class Morador {

    @Id
    private Integer id; // ID que vem do usuário

    @OneToOne
    @MapsId // Diz que o 'id' acima é preenchido automaticamente pelo ID do objeto Usuario
    @JoinColumn(name = "id") // Aponta para a coluna 'id' na tabela morador (que referencia o usuario)
    private Usuario usuario;

    @Column(name = "numero_do_quarto")
    private String numero_do_quarto;

    // ---- Dados financeiros (base do calculo de pendencias) ----

    @Column(name = "valor_mensalidade", precision = 10, scale = 2)
    private BigDecimal valorMensalidade;

    /** Dia do mes em que a mensalidade vence (1 a 28). */
    @Column(name = "dia_vencimento")
    private Integer diaVencimento;

    /** As mensalidades sao cobradas a partir do mes de entrada. */
    @Column(name = "data_entrada")
    private LocalDate dataEntrada;

    /** Preenchida quando o morador sai da residencia. */
    @Column(name = "data_saida")
    private LocalDate dataSaida;

    /** Morador nunca e apagado: ao sair, fica inativo e o historico continua guardado. */
    @Column(name = "ativo")
    private Boolean ativo = true;

    /** Registros antigos, criados antes desta coluna existir, contam como ativos. */
    public boolean estaAtivo() {
        return ativo == null || ativo;
    }
}
