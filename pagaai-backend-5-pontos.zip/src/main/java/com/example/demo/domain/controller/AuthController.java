package com.example.demo.domain.controller;

import com.example.demo.domain.dto.Request.AlterarSenhaRequest;
import com.example.demo.domain.dto.Request.LoginRequest;
import com.example.demo.domain.dto.Response.LoginResponse;
import com.example.demo.domain.model.Usuario;
import com.example.demo.domain.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin("*")
@RequestMapping("api/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    /** POST /api/auth/login  { "login": "admin@pagaai.com", "senha": "admin123" } */
    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@Valid @RequestBody LoginRequest request) {
        return ResponseEntity.ok(authService.login(request));
    }

    /** PUT /api/auth/senha  (precisa do token) */
    @PutMapping("/senha")
    public ResponseEntity<Void> alterarSenha(@AuthenticationPrincipal Usuario usuario,
                                             @Valid @RequestBody AlterarSenhaRequest request) {
        authService.alterarSenha(usuario, request);
        return ResponseEntity.noContent().build();
    }
}
