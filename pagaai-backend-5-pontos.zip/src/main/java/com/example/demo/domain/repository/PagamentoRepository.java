package com.example.demo.domain.repository;

import com.example.demo.domain.model.Pagamento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

/**
 * Todas as consultas ignoram pagamentos CANCELADOS.
 * "statusPagamento is null" inclui pagamentos antigos, criados antes do status ser preenchido.
 */
@Repository
public interface PagamentoRepository extends JpaRepository<Pagamento, Integer> {

    String VALIDO = "(p.statusPagamento is null or p.statusPagamento <> com.example.demo.domain.model.enums.StatusPagamento.CANCELADO)";

    @Query("select p from Pagamento p where " + VALIDO + " order by p.dateDoPagamento desc, p.id desc")
    List<Pagamento> listarValidos();

    @Query("select p from Pagamento p where " + VALIDO + " and p.morador.id = :moradorId "
            + "order by p.mesReferencia desc, p.dateDoPagamento desc")
    List<Pagamento> listarPorMorador(@Param("moradorId") Integer moradorId);

    @Query("select coalesce(sum(p.valor), 0) from Pagamento p where " + VALIDO
            + " and p.dateDoPagamento between :inicio and :fim")
    BigDecimal somarPorPeriodo(@Param("inicio") LocalDate inicio, @Param("fim") LocalDate fim);

    @Query("select coalesce(sum(p.valor), 0) from Pagamento p where " + VALIDO)
    BigDecimal somarTudo();

    /**
     * Total pago por morador e mes de referencia. Cada linha: [moradorId, mesReferencia, total].
     * Base do calculo de pendencias.
     */
    @Query("select p.morador.id, p.mesReferencia, sum(p.valor) from Pagamento p where " + VALIDO
            + " and p.mesReferencia is not null and p.morador is not null"
            + " group by p.morador.id, p.mesReferencia")
    List<Object[]> totaisPorMoradorEMes();
}
