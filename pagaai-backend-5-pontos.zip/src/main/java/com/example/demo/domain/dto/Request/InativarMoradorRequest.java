package com.example.demo.domain.dto.Request;

import java.time.LocalDate;

// Corpo opcional. Sem data, usa a data de hoje.
public record InativarMoradorRequest(LocalDate dataSaida) {
}
