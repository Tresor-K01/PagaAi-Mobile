package com.example.demo.domain.security;

import com.example.demo.domain.model.Usuario;
import com.example.demo.domain.model.enums.StatusUsuario;
import com.example.demo.domain.repository.UsuarioRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/** Ao iniciar a API, cria o administrador padrao se o e-mail dele ainda nao existir. */
@Component
public class AdminInicializador implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(AdminInicializador.class);

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Value("${pagaai.admin.nome}")
    private String nome;

    @Value("${pagaai.admin.email}")
    private String email;

    @Value("${pagaai.admin.telefone}")
    private String telefone;

    @Value("${pagaai.admin.senha}")
    private String senha;

    @Override
    public void run(ApplicationArguments args) {
        if (usuarioRepository.existsByEmail(email)) {
            return;
        }
        Usuario admin = new Usuario();
        admin.setNome(nome);
        admin.setEmail(email);
        admin.setTelefone(telefone);
        admin.setSenha(passwordEncoder.encode(senha));
        admin.setStatusUsuario(StatusUsuario.ROLE_ADMIN);
        usuarioRepository.save(admin);
        log.warn("Administrador padrao criado: {} (troque a senha!)", email);
    }
}
