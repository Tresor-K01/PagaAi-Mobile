package com.example.demo.domain.dto.Request;

import jakarta.validation.constraints.NotBlank;

// "login" aceita o e-mail ou o telefone
public record LoginRequest(
        @NotBlank(message = "Informe o e-mail ou telefone") String login,
        @NotBlank(message = "Informe a senha") String senha
) {
}
