package com.example.demo.domain.dto.Response;

import java.math.BigDecimal;
import java.time.LocalDate;

// Uma mensalidade nao paga (ou paga em parte)
public record MesPendenteResponse(
        String mes,              // "2026-09"
        LocalDate vencimento,
        BigDecimal valorDevido,
        BigDecimal valorPago,
        BigDecimal valorPendente
) {
}
