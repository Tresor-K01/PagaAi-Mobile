package com.example.demo.domain.dto.Request;

import jakarta.validation.constraints.*;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Cadastro e edicao de morador. No cadastro, a API cria tambem o login (usuario) do morador.
 * Exemplo:
 * { "nome": "Ana Souza", "email": "ana@email.com", "telefone": "92999990000", "senha": "ana12345",
 *   "numeroQuarto": "12", "valorMensalidade": 20.00, "diaVencimento": 10, "dataEntrada": "2026-07-01" }
 */
public record CadastroMoradorRequest(
        @NotBlank(message = "Informe o nome") @Size(max = 50) String nome,
        @NotBlank(message = "Informe o e-mail") @Email(message = "E-mail invalido") @Size(max = 50) String email,
        @NotBlank(message = "Informe o telefone") @Size(max = 30) String telefone,
        @Size(min = 6, message = "A senha precisa ter pelo menos 6 caracteres") String senha,
        @NotBlank(message = "Informe o quarto") @Size(max = 10) String numeroQuarto,
        @NotNull(message = "Informe a mensalidade") @PositiveOrZero BigDecimal valorMensalidade,
        @Min(1) @Max(28) Integer diaVencimento,
        @NotNull(message = "Informe a data de entrada") LocalDate dataEntrada
) {
}
