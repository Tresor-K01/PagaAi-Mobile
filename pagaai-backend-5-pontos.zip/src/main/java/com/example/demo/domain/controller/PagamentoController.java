package com.example.demo.domain.controller;

import com.example.demo.domain.dto.Request.PagamentoRequest;
import com.example.demo.domain.dto.Response.PagamentoResponse;
import com.example.demo.domain.model.Usuario;
import com.example.demo.domain.service.PagamentoService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
@RequestMapping("api/pagamentos")
public class PagamentoController {

    @Autowired
    private PagamentoService pagamentoService;

    /** ADMIN registra o pagamento de uma mensalidade. */
    @PostMapping
    public ResponseEntity<PagamentoResponse> cadastrarPagamento(@Valid @RequestBody PagamentoRequest request,
                                                                @AuthenticationPrincipal Usuario admin){
        return new ResponseEntity<>(pagamentoService.cadastrarPagamento(request, admin), HttpStatus.CREATED);
    }

    /** ADMIN: GET /api/pagamentos ou GET /api/pagamentos?moradorId=2 */
    @GetMapping
    public ResponseEntity<List<PagamentoResponse>> listarPagamentos(@RequestParam(required = false) Integer moradorId){
        return new ResponseEntity<>(pagamentoService.listarPagamentos(moradorId), HttpStatus.OK);
    }

    /** MORADOR: os pagamentos dele mesmo. O id vem do token, nunca da URL. */
    @GetMapping("/meus")
    public ResponseEntity<List<PagamentoResponse>> meusPagamentos(@AuthenticationPrincipal Usuario morador){
        return new ResponseEntity<>(pagamentoService.listarPagamentos(morador.getId()), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<PagamentoResponse> buscarPorId(@PathVariable Integer id){
        return new ResponseEntity<>(pagamentoService.buscarPorId(id), HttpStatus.OK);
    }

    @PatchMapping("/{id}/cancelar")
    public ResponseEntity<Void> cancelarPagamento(@PathVariable Integer id){
        pagamentoService.cancelarPagamento(id);
        return ResponseEntity.noContent().build();
    }
}
