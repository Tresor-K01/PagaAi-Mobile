package com.example.demo.domain.service;

import com.example.demo.domain.dto.Request.AlterarSenhaRequest;
import com.example.demo.domain.dto.Request.LoginRequest;
import com.example.demo.domain.dto.Response.LoginResponse;
import com.example.demo.domain.model.Morador;
import com.example.demo.domain.model.Usuario;
import com.example.demo.domain.model.enums.StatusUsuario;
import com.example.demo.domain.repository.MoradorRepository;
import com.example.demo.domain.repository.UsuarioRepository;
import com.example.demo.domain.security.JwtService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
public class AuthService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private MoradorRepository moradorRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtService jwtService;

    public LoginResponse login(LoginRequest request) {
        String login = request.login().trim();

        Usuario usuario = usuarioRepository.findFirstByEmailOrTelefone(login, login)
                .filter(u -> senhaConfere(request.senha(), u.getSenha()))
                // Mesma mensagem para login e senha errados: nao revela quais logins existem
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED,
                        "E-mail/telefone ou senha incorretos."));

        if (usuario.getStatusUsuario() == StatusUsuario.ROLE_MORADOR) {
            boolean ativo = moradorRepository.findById(usuario.getId()).map(Morador::estaAtivo).orElse(true);
            if (!ativo) {
                throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Morador inativo.");
            }
        }

        return new LoginResponse(jwtService.gerarToken(usuario), "Bearer", jwtService.getValidadeEmSegundos(),
                usuario.getId(), usuario.getNome(), usuario.getStatusUsuario());
    }

    @Transactional
    public void alterarSenha(Usuario logado, AlterarSenhaRequest request) {
        Usuario usuario = usuarioRepository.findById(logado.getId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Usuario nao encontrado."));
        if (!senhaConfere(request.senhaAtual(), usuario.getSenha())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "A senha atual esta incorreta.");
        }
        usuario.setSenha(passwordEncoder.encode(request.novaSenha()));
        usuarioRepository.save(usuario);
    }

    /** Senhas antigas gravadas em texto puro (antes do BCrypt) nao passam aqui. */
    private boolean senhaConfere(String digitada, String hashGuardado) {
        return hashGuardado != null && hashGuardado.startsWith("$2") && passwordEncoder.matches(digitada, hashGuardado);
    }
}
