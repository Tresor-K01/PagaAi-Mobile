package com.example.demo.domain.dto.Response;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

// Indicadores da tela inicial do administrador
public record DashboardAdminResponse(
        BigDecimal saldoAtual,
        LocalDate inicioPeriodo,
        LocalDate fimPeriodo,
        BigDecimal totalRecebidoPeriodo,
        BigDecimal totalDespesasPeriodo,
        long quantidadeMoradores,
        int quantidadeMoradoresComPendencia,
        BigDecimal valorTotalPendencias,
        List<MovimentacaoResponse> movimentacoesRecentes
) {
}
