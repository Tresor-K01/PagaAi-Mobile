package com.example.demo.domain.service;

import com.example.demo.domain.dto.Request.CadastroMoradorRequest;
import com.example.demo.domain.dto.Response.MoradorDetalheResponse;
import com.example.demo.domain.model.Morador;
import com.example.demo.domain.model.Usuario;
import com.example.demo.domain.model.enums.StatusUsuario;
import com.example.demo.domain.repository.MoradorRepository;
import com.example.demo.domain.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.List;

@Service
public class MoradorService {

    @Autowired
    private MoradorRepository moradorRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    /** Cria o usuario (login do morador) e o morador ligado a ele. */
    @Transactional
    public MoradorDetalheResponse cadastrarMorador(CadastroMoradorRequest request){
        if (request.senha() == null || request.senha().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Informe a senha inicial do morador.");
        }
        if (usuarioRepository.existsByEmail(request.email().trim())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Ja existe um usuario com este e-mail.");
        }
        if (usuarioRepository.existsByTelefone(request.telefone().trim())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Ja existe um usuario com este telefone.");
        }

        Usuario usuario = new Usuario();
        usuario.setNome(request.nome().trim());
        usuario.setEmail(request.email().trim());
        usuario.setTelefone(request.telefone().trim());
        usuario.setSenha(passwordEncoder.encode(request.senha()));
        usuario.setStatusUsuario(StatusUsuario.ROLE_MORADOR);
        usuario = usuarioRepository.save(usuario);

        Morador morador = new Morador();
        morador.setUsuario(usuario);
        preencherDadosFinanceiros(morador, request);
        morador.setAtivo(true);

        return toResponse(moradorRepository.save(morador));
    }

    /** Lista os ativos; com "busca", pesquisa por nome ou quarto; com "incluirInativos", traz todos. */
    public List<MoradorDetalheResponse> listarMorador(String busca, boolean incluirInativos){
        List<Morador> moradores;
        if (busca != null && !busca.isBlank()) {
            moradores = moradorRepository.pesquisar(busca.trim());
        } else if (incluirInativos) {
            moradores = moradorRepository.findAll();
        } else {
            moradores = moradorRepository.listarAtivos();
        }
        return moradores.stream().map(this::toResponse).toList();
    }

    public MoradorDetalheResponse buscarPorId(Integer id){
        return toResponse(obter(id));
    }

    /** Edita os dados do morador. A senha nao e alterada aqui. */
    @Transactional
    public MoradorDetalheResponse atualizarMorador(Integer id, CadastroMoradorRequest request){
        Morador morador = obter(id);
        Usuario usuario = morador.getUsuario();
        usuario.setNome(request.nome().trim());
        usuario.setEmail(request.email().trim());
        usuario.setTelefone(request.telefone().trim());
        usuarioRepository.save(usuario);

        preencherDadosFinanceiros(morador, request);
        return toResponse(moradorRepository.save(morador));
    }

    /** Saida da residencia: o morador fica inativo, perde o acesso ao app e o historico e preservado. */
    @Transactional
    public MoradorDetalheResponse inativarMorador(Integer id, LocalDate dataSaida){
        Morador morador = obter(id);
        if (!morador.estaAtivo()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Este morador ja esta inativo.");
        }
        morador.setAtivo(false);
        morador.setDataSaida(dataSaida != null ? dataSaida : LocalDate.now());
        return toResponse(moradorRepository.save(morador));
    }

    @Transactional
    public MoradorDetalheResponse reativarMorador(Integer id){
        Morador morador = obter(id);
        morador.setAtivo(true);
        morador.setDataSaida(null);
        return toResponse(moradorRepository.save(morador));
    }

    /** Busca o morador ou devolve 404. Usado tambem por outros services. */
    public Morador obter(Integer id){
        return moradorRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Morador " + id + " nao encontrado."));
    }

    private void preencherDadosFinanceiros(Morador morador, CadastroMoradorRequest request){
        morador.setNumero_do_quarto(request.numeroQuarto().trim());
        morador.setValorMensalidade(request.valorMensalidade());
        morador.setDiaVencimento(request.diaVencimento() != null ? request.diaVencimento() : 10);
        morador.setDataEntrada(request.dataEntrada());
    }

    private MoradorDetalheResponse toResponse(Morador morador){
        Usuario usuario = morador.getUsuario();
        return new MoradorDetalheResponse(
                morador.getId(),
                usuario != null ? usuario.getNome() : null,
                usuario != null ? usuario.getEmail() : null,
                usuario != null ? usuario.getTelefone() : null,
                morador.getNumero_do_quarto(),
                morador.getValorMensalidade(),
                morador.getDiaVencimento(),
                morador.getDataEntrada(),
                morador.getDataSaida(),
                morador.estaAtivo()
        );
    }

}
