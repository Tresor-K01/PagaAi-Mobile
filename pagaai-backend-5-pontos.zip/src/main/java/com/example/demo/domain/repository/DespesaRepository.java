package com.example.demo.domain.repository;

import com.example.demo.domain.model.Despesas;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface DespesaRepository extends JpaRepository<Despesas, Integer> {

    /** Soma das despesas com data entre inicio (inclusive) e fim (exclusive). */
    @Query("select coalesce(sum(d.valor), 0) from Despesas d where d.data >= :inicio and d.data < :fim")
    BigDecimal somarPorPeriodo(@Param("inicio") LocalDateTime inicio, @Param("fim") LocalDateTime fim);

    @Query("select coalesce(sum(d.valor), 0) from Despesas d")
    BigDecimal somarTudo();

    @Query("select d from Despesas d order by d.data desc nulls last, d.id desc")
    List<Despesas> listarRecentes();
}
