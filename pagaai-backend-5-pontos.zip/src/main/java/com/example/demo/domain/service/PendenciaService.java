package com.example.demo.domain.service;

import com.example.demo.domain.dto.Response.MesPendenteResponse;
import com.example.demo.domain.dto.Response.PendenciaResponse;
import com.example.demo.domain.model.Morador;
import com.example.demo.domain.model.Usuario;
import com.example.demo.domain.repository.MoradorRepository;
import com.example.demo.domain.repository.PagamentoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeParseException;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class PendenciaService {

    @Autowired
    private MoradorRepository moradorRepository;

    @Autowired
    private PagamentoRepository pagamentoRepository;

    @Autowired
    private MoradorService moradorService;

    /** Moradores ativos que tem mensalidades em atraso, do maior valor para o menor. */
    public List<PendenciaResponse> listarPendencias() {
        Map<Integer, Map<YearMonth, BigDecimal>> pagos = totaisPagos();
        LocalDate hoje = LocalDate.now();
        return moradorRepository.listarAtivos().stream()
                .map(m -> calcular(m, pagos.getOrDefault(m.getId(), Map.of()), hoje))
                .filter(p -> p.quantidadeMeses() > 0)
                .sorted(Comparator.comparing(PendenciaResponse::valorTotal).reversed())
                .toList();
    }

    /** Pendencias de um morador, mes a mes (funciona tambem para morador inativo). */
    public PendenciaResponse pendenciasDoMorador(Integer moradorId) {
        Morador morador = moradorService.obter(moradorId);
        return calcular(morador, totaisPagos().getOrDefault(moradorId, Map.of()), LocalDate.now());
    }

    /** Soma dos pagamentos validos, agrupada por morador e por mes de referencia. */
    private Map<Integer, Map<YearMonth, BigDecimal>> totaisPagos() {
        Map<Integer, Map<YearMonth, BigDecimal>> pagos = new HashMap<>();
        for (Object[] linha : pagamentoRepository.totaisPorMoradorEMes()) {
            Integer moradorId = (Integer) linha[0];
            YearMonth mes;
            try {
                mes = YearMonth.parse((String) linha[1]);
            } catch (DateTimeParseException e) {
                continue; // mes de referencia em formato invalido: ignora
            }
            BigDecimal total = (BigDecimal) linha[2];
            pagos.computeIfAbsent(moradorId, id -> new HashMap<>()).merge(mes, total, BigDecimal::add);
        }
        return pagos;
    }

    private PendenciaResponse calcular(Morador morador, Map<YearMonth, BigDecimal> pagos, LocalDate hoje) {
        List<MesPendenteResponse> meses = CalculadoraPendencias.calcular(morador.getValorMensalidade(),
                morador.getDiaVencimento(), morador.getDataEntrada(), morador.getDataSaida(), pagos, hoje);
        Usuario usuario = morador.getUsuario();
        return new PendenciaResponse(
                morador.getId(),
                usuario != null ? usuario.getNome() : null,
                morador.getNumero_do_quarto(),
                usuario != null ? usuario.getTelefone() : null,
                meses.size(),
                CalculadoraPendencias.total(meses),
                meses);
    }
}
