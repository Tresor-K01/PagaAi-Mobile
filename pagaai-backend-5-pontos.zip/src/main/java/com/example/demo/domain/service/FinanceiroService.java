package com.example.demo.domain.service;

import com.example.demo.domain.dto.Response.DashboardAdminResponse;
import com.example.demo.domain.dto.Response.MovimentacaoResponse;
import com.example.demo.domain.dto.Response.PendenciaResponse;
import com.example.demo.domain.model.Despesas;
import com.example.demo.domain.model.Pagamento;
import com.example.demo.domain.repository.DespesaRepository;
import com.example.demo.domain.repository.MoradorRepository;
import com.example.demo.domain.repository.PagamentoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Service
public class FinanceiroService {

    private static final int LIMITE_RECENTES = 10;

    @Autowired
    private PagamentoRepository pagamentoRepository;

    @Autowired
    private DespesaRepository despesaRepository;

    @Autowired
    private MoradorRepository moradorRepository;

    @Autowired
    private PendenciaService pendenciaService;

    /** Sem datas, o periodo e o mes atual. */
    public DashboardAdminResponse dashboard(LocalDate inicio, LocalDate fim) {
        YearMonth mesAtual = YearMonth.now();
        LocalDate ini = inicio != null ? inicio : mesAtual.atDay(1);
        LocalDate fi = fim != null ? fim : mesAtual.atEndOfMonth();
        if (ini.isAfter(fi)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "A data inicial nao pode ser depois da final.");
        }

        List<PendenciaResponse> pendencias = pendenciaService.listarPendencias();
        BigDecimal totalPendencias = pendencias.stream()
                .map(PendenciaResponse::valorTotal).reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal saldoAtual = pagamentoRepository.somarTudo().subtract(despesaRepository.somarTudo());

        return new DashboardAdminResponse(
                saldoAtual,
                ini, fi,
                pagamentoRepository.somarPorPeriodo(ini, fi),
                // despesas usam LocalDateTime: do inicio do 1o dia ate o inicio do dia seguinte ao ultimo
                despesaRepository.somarPorPeriodo(ini.atStartOfDay(), fi.plusDays(1).atStartOfDay()),
                moradorRepository.contarAtivos(),
                pendencias.size(),
                totalPendencias,
                movimentacoesRecentes());
    }

    /** Os ultimos pagamentos e despesas, juntos, do mais recente para o mais antigo. */
    private List<MovimentacaoResponse> movimentacoesRecentes() {
        List<MovimentacaoResponse> lista = new ArrayList<>();

        for (Pagamento p : pagamentoRepository.listarValidos().stream().limit(LIMITE_RECENTES).toList()) {
            String nome = p.getMorador() != null && p.getMorador().getUsuario() != null
                    ? p.getMorador().getUsuario().getNome() : "Morador";
            String mes = p.getMesReferencia() != null ? " " + p.getMesReferencia() : "";
            lista.add(new MovimentacaoResponse("RECEITA", p.getId(), "Mensalidade" + mes + " - " + nome,
                    p.getValor(), p.getDateDoPagamento()));
        }
        for (Despesas d : despesaRepository.listarRecentes().stream().limit(LIMITE_RECENTES).toList()) {
            String descricao = d.getCategoriaDespesa() != null ? d.getCategoriaDespesa().name() : "Despesa";
            lista.add(new MovimentacaoResponse("DESPESA", d.getId(), descricao, d.getValor(),
                    d.getData() != null ? d.getData().toLocalDate() : null));
        }

        lista.sort(Comparator.comparing(MovimentacaoResponse::data,
                Comparator.nullsLast(Comparator.reverseOrder())));
        return lista.size() > LIMITE_RECENTES ? lista.subList(0, LIMITE_RECENTES) : lista;
    }
}
