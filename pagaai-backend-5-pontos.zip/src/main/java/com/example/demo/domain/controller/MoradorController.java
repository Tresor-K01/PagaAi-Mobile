package com.example.demo.domain.controller;

import com.example.demo.domain.dto.Request.CadastroMoradorRequest;
import com.example.demo.domain.dto.Request.InativarMoradorRequest;
import com.example.demo.domain.dto.Response.MoradorDetalheResponse;
import com.example.demo.domain.service.MoradorService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

// Somente ADMIN (ver SecurityConfig)
@RestController
@CrossOrigin
@RequestMapping("api/morador")
public class MoradorController {

    @Autowired
    private MoradorService moradorService;

    @PostMapping
    public ResponseEntity<MoradorDetalheResponse> cadastrarMorador(@Valid @RequestBody CadastroMoradorRequest request) {
        return new ResponseEntity<>(moradorService.cadastrarMorador(request), HttpStatus.CREATED);
    }

    /** GET /api/morador?busca=ana&incluirInativos=false */
    @GetMapping
    public ResponseEntity<List<MoradorDetalheResponse>> listarMoradores(
            @RequestParam(required = false) String busca,
            @RequestParam(defaultValue = "false") boolean incluirInativos){
        return new ResponseEntity<>(moradorService.listarMorador(busca, incluirInativos), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<MoradorDetalheResponse> buscarPorId(@PathVariable Integer id){
        return new ResponseEntity<>(moradorService.buscarPorId(id), HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<MoradorDetalheResponse> atualizarMorador(@PathVariable Integer id,
                                                                   @Valid @RequestBody CadastroMoradorRequest request){
        return new ResponseEntity<>(moradorService.atualizarMorador(id, request), HttpStatus.OK);
    }

    @PatchMapping("/{id}/inativar")
    public ResponseEntity<MoradorDetalheResponse> inativarMorador(@PathVariable Integer id,
                                                                  @RequestBody(required = false) InativarMoradorRequest request){
        return new ResponseEntity<>(moradorService.inativarMorador(id, request != null ? request.dataSaida() : null), HttpStatus.OK);
    }

    @PatchMapping("/{id}/reativar")
    public ResponseEntity<MoradorDetalheResponse> reativarMorador(@PathVariable Integer id){
        return new ResponseEntity<>(moradorService.reativarMorador(id), HttpStatus.OK);
    }
}
